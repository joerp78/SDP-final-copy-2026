#include "bq35100.h"

// =========================
// Local helpers
// =========================
static void delay_ms(uint16_t ms)
{
    while (ms--)
    {
        __delay_cycles(1000);   // assumes MCLK/SMCLK = 1 MHz
    }
}

static void clock_init_1MHz(void)
{
    // FR2355 defaults are often usable, but set DCO = 1 MHz explicitly
    CSCTL0_H = CSKEY_H;                 // unlock CS registers
    CSCTL1 = DCOFSEL_0;                 // DCO = ~1 MHz
    CSCTL2 = SELM__DCOCLK | SELS__DCOCLK | SELA__REFOCLK;
    CSCTL3 = DIVM__1 | DIVS__1 | DIVA__1;
    CSCTL0_H = 0;                       // lock CS registers
}

static void i2c_init_b1(void)
{
    // Put eUSCI_B1 into reset
    UCB1CTLW0 = UCSWRST;

    // Select I2C function on P4.6/P4.7
    P4SEL0 |= BIT6 | BIT7;
    P4SEL1 &= ~(BIT6 | BIT7);

    // I2C master, synchronous
    UCB1CTLW0 |= UCMST | UCMODE_3 | UCSYNC;

    // SMCLK source
    UCB1CTLW0 |= UCSSEL__SMCLK;

    // ~100 kHz I2C from 1 MHz SMCLK
    UCB1BRW = 10;

    // Slave address
    UCB1I2CSA = BQ35100_I2C_ADDR;

    // Release reset
    UCB1CTLW0 &= ~UCSWRST;
}

static void gpio_init(void)
{
    // Gauge enable
    BQ_GE_DIR |= BQ_GE_PIN;
    BQ_GE_OUT &= ~BQ_GE_PIN;   // off by default
}

static bool i2c_write_bytes(uint8_t reg, const uint8_t *data, uint8_t len)
{
    uint8_t i;

    while (UCB1CTLW0 & UCTXSTP);

    UCB1I2CSA = BQ35100_I2C_ADDR;
    UCB1CTLW0 |= UCTR | UCTXSTT;

    while (!(UCB1IFG & UCTXIFG0));
    UCB1TXBUF = reg;

    for (i = 0; i < len; i++)
    {
        while (!(UCB1IFG & UCTXIFG0));
        UCB1TXBUF = data[i];
    }

    while (!(UCB1IFG & UCTXIFG0));
    UCB1CTLW0 |= UCTXSTP;

    while (UCB1CTLW0 & UCTXSTP);
    return true;
}

static bool i2c_read_bytes(uint8_t reg, uint8_t *data, uint8_t len)
{
    uint8_t i;

    while (UCB1CTLW0 & UCTXSTP);

    UCB1I2CSA = BQ35100_I2C_ADDR;

    // Write register address
    UCB1CTLW0 |= UCTR | UCTXSTT;

    while (!(UCB1IFG & UCTXIFG0));
    UCB1TXBUF = reg;

    while (!(UCB1IFG & UCTXIFG0));

    // Repeated start, receiver mode
    UCB1CTLW0 &= ~UCTR;
    UCB1CTLW0 |= UCTXSTT;

    while (UCB1CTLW0 & UCTXSTT);

    for (i = 0; i < len; i++)
    {
        if (i == (len - 1))
        {
            UCB1CTLW0 |= UCTXSTP;
        }

        while (!(UCB1IFG & UCRXIFG0));
        data[i] = UCB1RXBUF;
    }

    while (UCB1CTLW0 & UCTXSTP);
    return true;
}

// =========================
// Public API
// =========================
void BQ35100_init(void)
{
    WDTCTL = WDTPW | WDTHOLD;
    clock_init_1MHz();
    gpio_init();
    i2c_init_b1();
}

void BQ35100_powerOn(void)
{
    BQ_GE_OUT |= BQ_GE_PIN;
    delay_ms(300);   // datasheet power-up communication time is 250 ms typ
}

void BQ35100_powerOff(void)
{
    BQ_GE_OUT &= ~BQ_GE_PIN;
}

uint8_t BQ35100_read8(uint8_t reg)
{
    uint8_t val = 0;
    i2c_read_bytes(reg, &val, 1);
    return val;
}

uint16_t BQ35100_read16(uint8_t reg)
{
    uint8_t buf[2] = {0, 0};
    i2c_read_bytes(reg, buf, 2);

    // little-endian: LSB at lower address
    return ((uint16_t)buf[1] << 8) | buf[0];
}

uint32_t BQ35100_read32(uint8_t reg)
{
    uint8_t buf[4] = {0, 0, 0, 0};
    i2c_read_bytes(reg, buf, 4);

    return ((uint32_t)buf[3] << 24) |
           ((uint32_t)buf[2] << 16) |
           ((uint32_t)buf[1] << 8)  |
            (uint32_t)buf[0];
}

bool BQ35100_control(uint16_t subcmd)
{
    uint8_t buf[2];
    buf[0] = (uint8_t)(subcmd & 0xFF);
    buf[1] = (uint8_t)((subcmd >> 8) & 0xFF);

    return i2c_write_bytes(BQ_REG_CONTROL, buf, 2);
}

bool BQ35100_gaugeStart(void)
{
    return BQ35100_control(BQ_CMD_GAUGE_START);
}

bool BQ35100_gaugeStop(void)
{
    return BQ35100_control(BQ_CMD_GAUGE_STOP);
}

bool BQ35100_newBattery(void)
{
    return BQ35100_control(BQ_CMD_NEW_BATTERY);
}

uint16_t BQ35100_readVoltage_mV(void)
{
    return BQ35100_read16(BQ_REG_VOLTAGE);
}

int16_t BQ35100_readTemperature_dC(void)
{
    // Register is signed integer in 0.1 K
    // Convert to 0.1 °C: T(0.1°C) = T(0.1K) - 2731
    int16_t t_dK = (int16_t)BQ35100_read16(BQ_REG_TEMPERATURE);
    return (int16_t)(t_dK - 2731);
}

int16_t BQ35100_readCurrent_mA(void)
{
    return (int16_t)BQ35100_read16(BQ_REG_CURRENT);
}

uint8_t BQ35100_readBatteryStatus(void)
{
    return BQ35100_read8(BQ_REG_BAT_STATUS);
}

uint8_t BQ35100_readSOH_percent(void)
{
    return (uint8_t)BQ35100_read16(BQ_REG_SOH);
}

uint32_t BQ35100_readAccumulated_uAh(void)
{
    return BQ35100_read32(BQ_REG_ACC_CAP);
}

bool BQ35100_readSnapshot(BQ35100_Data_t *out)
{
    if (out == 0)
    {
        return false;
    }

    BQ35100_powerOn();

    // Read status first to clear/init the device side flow
    out->battery_status = BQ35100_readBatteryStatus();

    // Optional gauge cycle
    BQ35100_gaugeStart();
    delay_ms(50);

    out->voltage_mV      = BQ35100_readVoltage_mV();
    out->temperature_dC  = BQ35100_readTemperature_dC();
    out->current_mA      = BQ35100_readCurrent_mA();
    out->soh_percent     = BQ35100_readSOH_percent();
    out->accumulated_uAh = BQ35100_readAccumulated_uAh();

    BQ35100_gaugeStop();
    delay_ms(50);

    BQ35100_powerOff();
    return true;
}
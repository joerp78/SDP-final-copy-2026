#ifndef BQ35100_H_
#define BQ35100_H_

#include <msp430.h>
#include <stdint.h>
#include <stdbool.h>

// =========================
// User pin mapping
// =========================
#define BQ35100_I2C_ADDR      0x55

// I2C on eUSCI_B1
// P4.6 -> UCB1SDA
// P4.7 -> UCB1SCL

// Gauge enable pin
#define BQ_GE_DIR             P5DIR
#define BQ_GE_OUT             P5OUT
#define BQ_GE_PIN             BIT2

// =========================
// BQ35100 register map
// =========================
#define BQ_REG_CONTROL        0x00
#define BQ_REG_ACC_CAP        0x02
#define BQ_REG_TEMPERATURE    0x06
#define BQ_REG_VOLTAGE        0x08
#define BQ_REG_BAT_STATUS     0x0A
#define BQ_REG_BAT_ALERT      0x0B
#define BQ_REG_CURRENT        0x0C
#define BQ_REG_SOH            0x2E

// =========================
// BQ35100 control subcommands
// =========================
#define BQ_CMD_CONTROL_STATUS 0x0000
#define BQ_CMD_DEVICE_TYPE    0x0001
#define BQ_CMD_FW_VERSION     0x0002
#define BQ_CMD_GAUGE_START    0x0011
#define BQ_CMD_GAUGE_STOP     0x0012
#define BQ_CMD_RESET          0x0041
#define BQ_CMD_NEW_BATTERY    0xA613

typedef struct
{
    uint16_t voltage_mV;
    int16_t  temperature_dC;     // 0.1 °C
    int16_t  current_mA;
    uint8_t  battery_status;
    uint8_t  soh_percent;
    uint32_t accumulated_uAh;
} BQ35100_Data_t;

// Init
void BQ35100_init(void);

// Power control
void BQ35100_powerOn(void);
void BQ35100_powerOff(void);

// Low-level reads
uint8_t  BQ35100_read8(uint8_t reg);
uint16_t BQ35100_read16(uint8_t reg);
uint32_t BQ35100_read32(uint8_t reg);

// Commands
bool BQ35100_control(uint16_t subcmd);
bool BQ35100_gaugeStart(void);
bool BQ35100_gaugeStop(void);
bool BQ35100_newBattery(void);

// High-level reads
uint16_t BQ35100_readVoltage_mV(void);
int16_t  BQ35100_readTemperature_dC(void);
int16_t  BQ35100_readCurrent_mA(void);
uint8_t  BQ35100_readBatteryStatus(void);
uint8_t  BQ35100_readSOH_percent(void);
uint32_t BQ35100_readAccumulated_uAh(void);

// One-shot convenience read
bool BQ35100_readSnapshot(BQ35100_Data_t *out);

#endif
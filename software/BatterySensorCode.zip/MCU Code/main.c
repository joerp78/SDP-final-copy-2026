#include <msp430.h>
#include <stdint.h>
#include "bq35100.h"

volatile BQ35100_Data_t g_batt;

int main(void)
{
    BQ35100_init();

    while (1)
    {
        BQ35100_readSnapshot((BQ35100_Data_t *)&g_batt);

        // Example breakpoint values:
        // g_batt.voltage_mV
        // g_batt.temperature_dC
        // g_batt.current_mA
        // g_batt.soh_percent
        // g_batt.accumulated_uAh

        __delay_cycles(1000000);   // 1 second at 1 MHz
    }
}